A Pen created at CodePen.io. You can find this one at https://codepen.io/adeveloperdiary/pen/OydzpG.

 We will learn how to animate an object (e.g. Icon) along with the progress indicator using d3.js. Find the full tutorial here: http://www.adeveloperdiary.com/d3-js/create-custom-progress-chart-using-d3-js-part1/