A Pen created at CodePen.io. You can find this one at https://codepen.io/bphillips201/pen/jCuDA.

 Experimenting with ways to display social links