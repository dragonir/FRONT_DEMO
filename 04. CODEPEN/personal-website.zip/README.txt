A Pen created at CodePen.io. You can find this one at https://codepen.io/terf/pen/vgurb.

 This was V1 of my personal website, <a href="http://timothy.expert">http://timothy.expert</a>. The current version, V2, is <a href="http://codepen.io/terf/pen/XbQwrL">here</a>.