A Pen created at CodePen.io. You can find this one at https://codepen.io/ARS/pen/sLDjh.

 Circular music player on HTML5 and CSS3. Features: - Canvas progress bar. - Full width album cover. - Lyrics support. - Playlist on backside. - 3D animation. - Responsive design.