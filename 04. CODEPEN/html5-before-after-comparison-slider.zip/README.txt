A Pen created at CodePen.io. You can find this one at https://codepen.io/dudleystorey/pen/HkwBo.

 Uses customised range input for slider. More details [on my blog](http://thenewcode.com/819/A-Before-And-After-Image-Comparison-Slide-Control-in-HTML5)