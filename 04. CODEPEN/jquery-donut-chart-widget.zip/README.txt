A Pen created at CodePen.io. You can find this one at https://codepen.io/drewworthey/pen/dDHvu.

 This is an easily and heavily configurable, JSON-feedable donut chart, designed for quick viewing of dashboard-style data.