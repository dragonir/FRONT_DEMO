$(document).ready(function(){
  $(".draggable_box").draggable({handle: 'div', drag: function(){reset();}});
  reset();
});

var canvas = document.getElementsByTagName("canvas")[0];
var ctx = canvas.getContext("2d");

var w = window.innerWidth, h = window.outerHeight;
canvas.width = w;
canvas.height = h;

function reset(){
  ctx.fillStyle = "#333";
  ctx.fillRect(0,0,w,h);
  drawscene();
}

function drawscene(){
  ctx.beginPath();
  ctx.moveTo((Math.floor($(".box1").css("left").replace("px",""))+230),(Math.floor($(".box1").css("top").replace("px",""))+50));
  ctx.lineTo((Math.floor($(".box1").css("left").replace("px",""))+250),(Math.floor($(".box1").css("top").replace("px",""))+50));
  ctx.lineTo((Math.floor($(".box2").css("left").replace("px",""))-20),(Math.floor($(".box2").css("top").replace("px",""))+50));
  ctx.lineTo(Math.floor($(".box2").css("left").replace("px","")),(Math.floor($(".box2").css("top").replace("px",""))+50));
  ctx.strokeStyle = "#F3442B";
  ctx.lineWidth = 10;
  ctx.stroke();
  
  ctx.beginPath();
  ctx.moveTo((Math.floor($(".box1").css("left").replace("px",""))+230),(Math.floor($(".box1").css("top").replace("px",""))+70));
  ctx.lineTo((Math.floor($(".box1").css("left").replace("px",""))+242),(Math.floor($(".box1").css("top").replace("px",""))+70));
  ctx.lineTo((Math.floor($(".box3").css("left").replace("px",""))-20),(Math.floor($(".box3").css("top").replace("px",""))+50));
  ctx.lineTo(Math.floor($(".box3").css("left").replace("px","")),(Math.floor($(".box3").css("top").replace("px",""))+50));
  ctx.strokeStyle = "#A9CE00";
  ctx.lineWidth = 10;
  ctx.stroke();
  
  ctx.beginPath();
  ctx.moveTo((Math.floor($(".box1").css("left").replace("px",""))+230),(Math.floor($(".box1").css("top").replace("px",""))+100));
  ctx.lineTo((Math.floor($(".box1").css("left").replace("px",""))+240),(Math.floor($(".box1").css("top").replace("px",""))+100));
  ctx.lineTo((Math.floor($(".box4").css("left").replace("px",""))-20),(Math.floor($(".box4").css("top").replace("px",""))+50));
  ctx.lineTo(Math.floor($(".box4").css("left").replace("px","")),(Math.floor($(".box4").css("top").replace("px",""))+50));
  ctx.strokeStyle = "#1EC3FF";
  ctx.lineWidth = 10;
  ctx.stroke();
  
  ctx.beginPath();
  ctx.moveTo((Math.floor($(".box1").css("left").replace("px",""))+230),(Math.floor($(".box1").css("top").replace("px",""))+130));
  ctx.lineTo((Math.floor($(".box1").css("left").replace("px",""))+240),(Math.floor($(".box1").css("top").replace("px",""))+130));
  ctx.lineTo((Math.floor($(".box5").css("left").replace("px",""))-20),(Math.floor($(".box5").css("top").replace("px",""))+50));
  ctx.lineTo(Math.floor($(".box5").css("left").replace("px","")),(Math.floor($(".box5").css("top").replace("px",""))+50));
  ctx.strokeStyle = "#7B78E9";
  ctx.lineWidth = 10;
  ctx.stroke();
}