A Pen created at CodePen.io. You can find this one at https://codepen.io/motorlatitude/pen/fJGny.

 Some sort of flow chart idea I had for seeing all files connected to a website, the lines are drawn using html5 canvas and the rest is css with a bit jquery ui for the dragging