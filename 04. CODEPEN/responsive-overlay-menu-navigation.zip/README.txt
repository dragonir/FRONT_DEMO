A Pen created at CodePen.io. You can find this one at https://codepen.io/riogrande/pen/gbXxdx.

 Responsive flat animated overlay menu using css html and jquery nav navigation. There are two menus, classic and hamburger menu with full screen overlay. Its also flat. Links work when menu is downloaded. Icons from fontawesome 