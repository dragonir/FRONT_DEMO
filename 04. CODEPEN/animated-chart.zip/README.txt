A Pen created at CodePen.io. You can find this one at https://codepen.io/christiannaths/pen/yNBjBq.

 Saw this on Dribbble today: https://dribbble.com/shots/2025084 and thought it might be a fun experiment to an HMTL/CSS version.