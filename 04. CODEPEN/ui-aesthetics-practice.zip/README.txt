A Pen created at CodePen.io. You can find this one at https://codepen.io/AllanJeremy/pen/yXrVzx.

 Working on a personal site* as practice on UI design since I am more of a backend person.

Also doubles as my portfolio project for  FreeCodeCamp.

Between my first pen (Tribute page) and this pen, I have read a couple of articles on UI design and as such intend to use this as an improvement project.

Feel free to copy paste and use this design for your own site.

Credit is not necessary but would be highly appreciated