A Pen created at CodePen.io. You can find this one at https://codepen.io/dazulu/pen/tcwDo.

 My first attempt at coding a game using html, css and jQuery. It's pretty random as far as games go and I know canvas is likely a far better choice here but I just wanted to see if I could pull it off. Anyway... enjoy! :)


I messed around with the %'s until it felt about right:

5% chance for a chest (1500 pts). 1 per game.
58% chance for a gem (500 pts).
Water gives you nothing.

Image assets are part of "Danc's Miraculously Flexible Game Prototyping Tiles" http://www.lostgarden.com/2007/05/dancs-miraculously-flexible-game.html

Sounds: Me :)