A Pen created at CodePen.io. You can find this one at https://codepen.io/alexnoz/pen/brazWd.

 Responsive (sort of?). Uses this technique for smooth transitions on mouse move - https://codepen.io/rachsmith/post/animation-tip-lerp