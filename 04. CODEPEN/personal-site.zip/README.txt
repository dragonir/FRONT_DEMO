A Pen created at CodePen.io. You can find this one at https://codepen.io/hynden/pen/tHGpA.

 Also available to use with keyboard:
1, 2, 3, 4 and Escape. Small media-query tweeks not included here. 
