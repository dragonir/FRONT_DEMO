A Pen created at CodePen.io. You can find this one at https://codepen.io/program247365/pen/oLYPEa.

 A static MP3 player, inspired by https://dribbble.com/shots/2756727-Mp3-Player.