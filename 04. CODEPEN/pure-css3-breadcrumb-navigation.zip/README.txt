A Pen created at CodePen.io. You can find this one at https://codepen.io/arkev/pen/DzCKF.

 breadcrumb navigation using pure CSS3