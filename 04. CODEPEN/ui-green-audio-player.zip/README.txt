A Pen created at CodePen.io. You can find this one at https://codepen.io/gregh/pen/NdVvbm.

 An audio player written in javascript by Greg Hovanesyan, free for stealing and modifying