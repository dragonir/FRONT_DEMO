A Pen created at CodePen.io. You can find this one at https://codepen.io/nikhil8krishnan/pen/rVoXJa.

 All loaders are animated with pure SVG animation. 