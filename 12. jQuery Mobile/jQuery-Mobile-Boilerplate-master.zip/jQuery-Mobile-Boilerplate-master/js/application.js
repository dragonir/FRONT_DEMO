/* 
	jQuery Mobile Boilerplate
	application.js
*/
$(document).on("pageinit", function(event){
	// custom code goes here



});