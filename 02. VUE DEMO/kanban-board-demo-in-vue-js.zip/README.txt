A Pen created at CodePen.io. You can find this one at https://codepen.io/nigamshirish/pen/XgqOVO.

 Demo of kanban board with todo, doing and done lists and let you organise your tasks and also let you drag and drop cards among the lists.  This pen is built using bootstrap 4, vue.js,  sortable.js and underscore.js.    
