'use strict';

Vue.directive('sortable', {
  inserted: function inserted(el, binding) {
    var sortable = new Sortable(el, binding.value || {});
  }

});

Vue.component('nav-header', {
  template: '#nav-template'
});

Vue.component('card-new', {
  template: '#card-new-template',
  props: ['item'],
  data: function data() {
    return {
      form: {
        text: '',
        list: ''
      },
      isFormShowing: false
    };
  },

  computed: {},
  methods: {
    handleNew: function handleNew() {
      this.form.text = this.item.text;
      this.form.list = this.item.list;
      this.isFormShowing = true;
    },
    cancelForm: function cancelForm() {
      this.clearForm();
      this.$emit('form-cancelled');
      this.isFormShowing = false;
    },
    clearForm: function clearForm() {
      this.form.text = '';
      this.form.list = '';
    },
    save: function save() {
      var min = 1000;
      var max = 5000;
      var id = Math.floor(Math.random() * (max - min + 1)) + min;
      var item = { id: id, text: this.form.text, list: this.form.list };
      this.$emit('item-created', item);
      this.clearForm();
      this.isFormShowing = false;
    },
    cancel: function cancel() {
      this.$emit('item-cancelled');
      this.clearForm();
      this.isFormShowing = false;
    }
  }
});

Vue.component('card-edit', {
  template: '#card-edit-template',
  props: ['item'],
  data: function data() {
    return {
      form: {
        id: '',
        text: '',
        list: ''
      },
      isEditing: false
    };
  },

  computed: {},
  methods: {
    handleEdit: function handleEdit() {
      this.form.id = this.item.id;
      this.form.text = this.item.text;
      this.form.list = this.item.list;
      this.isEditing = true;
    },
    cancelForm: function cancelForm() {
      this.clearForm();
      this.$emit('form-cancelled');
    },
    clearForm: function clearForm() {
      this.form.id = '';
      this.form.text = '';
      this.form.list = '';
    },
    save: function save() {
      var item = { id: this.form.id, text: this.form.text, list: this.form.list };
      this.$emit('item-edited', item);
      this.clearForm();
      this.isEditing = false;
    },
    cancel: function cancel() {
      this.$emit('item-cancelled');
      this.clearForm();
      this.isEditing = false;
    }
  }

});

Vue.component('list', {

  template: '#list-template',

  props: ['list_name', 'list_description', 'lists', 'list_items', 'item_text', 'header_color'],

  data: function data() {
    return {
      editItem: null,
      showForm: false
    };
  },

  computed: {
    filteredListItems: function filteredListItems() {
      var _this = this;

      return this.list_items.filter(function (t) {
        return t.list == _this.list_name;
      });
    },
    defaultItem: function defaultItem() {

      return { id: 0, text: this.item_text, list: this.list_name };
    },
    sortableConfig: function sortableConfig() {

      return {
        onAdd: this.putItem,
        draggable: '.draggable-card',
        group: { name: this.list_name, put: this.list_put }
      };
    }
  },

  methods: {
    list_put: function list_put() {
      var _this2 = this;

      return this.lists.filter(function (t) {
        return t !== _this2.list_name;
      });
    },
    putItem: function putItem(evt) {

      var idx = _.findIndex(this.list_items, function (t) {
        return t.id == evt.item.id;
      });
      var item = this.list_items[idx];
      item.list = evt.to.dataset.type;
      this.list_items.splice(idx, 1, item);
    },
    showEditForm: function showEditForm(item) {
      this.editItem = item;
      this.showForm = true;
    },
    showNewForm: function showNewForm() {
      this.editItem = null;
      this.showForm = true;
    },
    closeForm: function closeForm() {
      this.showForm = false;
    },
    itemCreated: function itemCreated(item) {
      this.list_items.push(item);
      this.closeForm();
    },
    itemEdited: function itemEdited(item) {
      console.log(item);
      var idx = _.findIndex(this.list_items, function (t) {
        return t.id == item.id;
      });
      var itm = this.list_items[idx];
      itm.list = item.list;
      itm.text = item.text;
      this.list_items.splice(idx, 1, itm);
      this.closeForm();
    },
    itemCancelled: function itemCancelled() {
      this.closeForm();
    }
  }
});

Vue.component('board', {

  template: '#board-template',

  data: function data() {

    return {

      lists: [{ name: 'todo', description: 'To Do', header_color: 'bg-info' }, { name: 'doing', description: 'Doing', header_color: 'bg-warning' }, { name: 'done', description: 'Done', header_color: 'bg-success' }],

      items: [{ id: 1, text: 'Build the feature #1', list: 'todo' }, { id: 2, text: 'Test the feature #1', list: 'todo' }, { id: 3, text: 'Commit feature #1 to the repository', list: 'todo' }, { id: 4, text: 'Deploy the feature #1', list: 'todo' }, { id: 5, text: 'Build the demo app', list: 'doing' }, { id: 6, text: 'Put in some sample data in app', list: 'doing' }, { id: 7, text: 'Test the app before launching', list: 'doing' }, { id: 8, text: 'Set up app landing page ', list: 'done' }, { id: 9, text: 'Send out email invitations to the subscribers', list: 'done' }]
    };
  }
});

new Vue({ el: '#app' });