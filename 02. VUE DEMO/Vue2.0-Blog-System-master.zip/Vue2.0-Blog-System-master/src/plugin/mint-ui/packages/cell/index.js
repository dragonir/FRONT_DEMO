import Cell from './src/cell.vue';
module.exports = Cell;
