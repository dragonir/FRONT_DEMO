import Badge from './src/badge.vue';
module.exports = Badge;
