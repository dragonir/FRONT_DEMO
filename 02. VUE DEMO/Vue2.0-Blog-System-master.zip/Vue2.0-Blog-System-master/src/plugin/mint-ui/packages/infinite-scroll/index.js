import InfiniteScroll from './src/infinite-scroll.js';
import 'mint-ui/src/style/empty.css';

module.exports = InfiniteScroll;
