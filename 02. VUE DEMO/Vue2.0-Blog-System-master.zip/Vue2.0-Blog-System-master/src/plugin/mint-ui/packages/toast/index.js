import Toast from './src/toast.js';
module.exports = Toast;
