import Field from './src/field.vue';
module.exports = Field;
