import './polyfills.js'
import manager from './manager'

export default manager
