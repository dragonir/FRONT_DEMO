/**
 * Description:
 */
// 这个 getter 函数会返回 count 的值
// 在 ES6 里你可以写成：
// export const getCount = state => state.count

// getters,从store的state中获取整个状态对象作为其唯一参数
// export function getCount (state) {
//     return state.count
// }