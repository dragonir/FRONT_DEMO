#!/bin/bash
git add -A
git commit -m $*
git push

