<template>
    <div class="index-bottom-info text-center text-overflow">
        <p><i class="fa fa-copyright"></i><span> 2015-2016 All Rights Reserved.</span><span class="hidden-xs">Designed by Songtao.渝ICP备16000583号.</span></p>
    </div>
</template>
<style scoped lang="scss">
    .index-bottom-info {
        user-select: none;
        -webkit-user-select: none;
        position: relative;
        width: auto;
        color: #eee;
        font-size: 12px;
        p {
            overflow: hidden;
        }
    }
</style>
