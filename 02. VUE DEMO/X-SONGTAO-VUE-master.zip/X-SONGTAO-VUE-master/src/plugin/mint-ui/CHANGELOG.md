# 2016.07.25 v0.1.23
- fixed lost style file
- fixed repeat packed font file
