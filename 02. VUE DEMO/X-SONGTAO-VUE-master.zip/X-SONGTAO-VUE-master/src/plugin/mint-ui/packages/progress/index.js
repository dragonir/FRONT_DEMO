import Progress from './src/progress.vue';
module.exports = Progress;
