import Checklist from './src/checklist.vue';
module.exports = Checklist;
