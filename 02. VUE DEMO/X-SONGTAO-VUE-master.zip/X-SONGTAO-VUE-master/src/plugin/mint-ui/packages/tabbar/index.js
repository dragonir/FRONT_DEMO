import Tabbar from './src/tabbar.vue';
module.exports = Tabbar;
