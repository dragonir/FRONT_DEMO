import TabItem from './src/tab-item.vue';
module.exports = TabItem;
