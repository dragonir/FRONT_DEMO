import MessageBox from './src/message-box.js';
module.exports = MessageBox;
