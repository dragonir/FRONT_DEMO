module.exports = require('./src/cell-swipe.vue');
