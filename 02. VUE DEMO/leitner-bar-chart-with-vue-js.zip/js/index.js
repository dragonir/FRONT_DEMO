"use strict";

// backend php would generate this (for example, encoded json in a input["hidden"])
var chart_data = {
  // eight Leitner boxes, each box contains 2 piles, each pile has { value: ..., type: ... }
  // first pile contains missed cards (failed) and new cards (new)
  // 2nd box and higher have due cards (due) and scheduled cards (fresh)
  "boxes":[
    [
      {
        "value":5,
        "type":"failed"
      },
      {
        "value":11,
        "type":"new"
      }
    ],
    [
      {
        "value":16,
        "type":"due"
      },
      {
        "value":0,
        "type":"fresh"
      }
    ],
    [
      {
        "value":4,
        "type":"due"
      },
      {
        "value":0,
        "type":"fresh"
      }
    ],
    [
      {
        "value":9,
        "type":"due"
      },
      {
        "value":0,
        "type":"fresh"
      }
    ],
    [
      {
        "value":0,
        "type":"due"
      },
      {
        "value":0,
        "type":"fresh"
      }
    ],
    [
      {
        "value":0,
        "type":"due"
      },
      {
        "value":1,
        "type":"fresh"
      }
    ],
    [
      {
        "value":26,
        "type":"due"
      },
      {
        "value":0,
        "type":"fresh"
      }
    ],
    [
      {
        "value":4,
        "type":"due"
      },
      {
        "value":9,
        "type":"fresh"
      }
    ]
  ]
};

  var Helpers = {
    getRandomIntInclusive: function(min, max) {
      min = Math.ceil(min);
      max = Math.floor(max);
      return Math.floor(Math.random() * (max - min + 1)) + min;
    }
  };

  Vue.component('leitner-chart', {

    data: function() {
      return {
        boxes: chart_data.boxes,
        box_labels: [
          'Failed & New', 'One review', 'Two reviews', 'Three reviews', 'Four reviews', 'Five reviews', 'Six reviews', 'Seven+'
        ],

        colors: { failed: '#ff8257', new: '#40a8e5', fresh: '#5ad177', due: '#ffa443' }
      };
    },

    methods: {
      getColor: function(type) {
        return this.colors[type];
      },
      getPercent: function(height) {
        // console.log('getPercent(%o)', height);
        return this.maxHeight > 0 ? Math.ceil(height * 100 / this.maxHeight) : 0;
      },
      getHeight: function(bar) {
        // console.log('getHeight(%o)', bar.value);
        var height = this.getPercent(bar.value);

        return (height > 0 && height < 4 ? '4px' : height + '%');
      },

      onClick: function(ev) {
        console.log("onClick(%o) target: %o", ev, ev.target);
      },

      updateChartTestOne: function() {
        // increase one stack
        this.stacks[3].value++;
      },
      updateChartTestTwo: function() {
        // randomize
        this.stacks.forEach(function(stack, i) {
          // make it look like a typical review
          if (i < 2) {
            // failed & new
            stack.value = Math.max(Helpers.getRandomIntInclusive(0, (i % 2 === 0 ? 10 : 20)) + 5, 0);
          }
          else {
            // due and scheduled
            stack.value = Math.max(Helpers.getRandomIntInclusive(0, (i % 2 === 0 ? 20 : 30)) - 5, 0);
          }
        });
      },

      removeBox: function() {
        if (this.boxes.length > 1) {
          this.boxes.pop();         
        }
      },
      addBox: function() {
        var newbox = [
          { value: Helpers.getRandomIntInclusive(0,10), type: 'due' },
          { value: Helpers.getRandomIntInclusive(1,15), type: 'fresh' }
        ];
        this.boxes.push(newbox);
      }

    },

    computed: {
      stacks: function() {
        console.log("... update property: stacks ...");
        // reformat leitner data from 8 boxes to 16 stacks
        var bars = [];
        this.boxes.map( function(b) { bars.push(b[0], b[1]); });
        return bars;
      },

      maxHeight: function() {
        console.log("... update property: maxHeight ...");
        var vals = this.stacks.map(function(s) { return s.value; });
        var c = Math.max.apply(null, vals);
        return c;
      }
    },

    template: '#leitner-chart-template'
  });

  var vm = new Vue({
    el: '#app',

    data: {
      // ...
    },

    methods: {
      // ...
    }

  });