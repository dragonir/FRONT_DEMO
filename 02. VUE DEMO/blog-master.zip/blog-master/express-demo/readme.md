## express-demo
express + mongoose 实现增删查改的例子。

相关文章地址：[Node.js 入门：Express + Mongoose 基础使用](http://blog.gdfengshuo.com/2017/07/29/20)

### 安装
下载代码，进入 express-demo 目录
```
npm install
npm start
```
启动后浏览器访问：http://localhost:3000