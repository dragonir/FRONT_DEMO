'use strict';

Vue.component('note', {
  template: '<div class="note" v-if="template==\'standard\'">\n    <div class="note__left">\n     <img :src="$parent.imageUrl +$parent.width+\'/\'+$parent.height+\'?image=\' + image"></img>\n    </div>\n    <div class="note__right">\n      <p class="note__text">{{text}}</p>\n      <p class="note__date">{{date}}</p>\n    </div>\n  </div>\n  <div class="note" v-else-if="template==\'modern\'" :style="\'background-image:url(\'+$parent.imageUrl +$parent.width+\'/\'+$parent.height+\'?image=\' + image+\')\'">\n    <div class="note__inner">\n      <p class="note__text">{{text}}</p>\n      <p class="note__date">{{date}}</p>\n    </div>\n  </div>\n',
  props: ['text', 'date', 'image', 'template'],
  methods: {}
});

var app = new Vue({
  el: '#app',
  data: function data() {
    return {
      newNote: null,
      img: 0,
      width: 100,
      height: 100,
      template: 'standard',
      lastItem: null,
      selectedIndex: null,
      notes: [],
      imageUrl: 'https://unsplash.it/'
    };
  },

  methods: {
    getRandomColor: function getRandomColor() {
      return 'rgba(' + (Math.floor(Math.random() * 56) + 200) + ', ' + (Math.floor(Math.random() * 56) + 200) + ', ' + (Math.floor(Math.random() * 56) + 200) + ',.2)';
    },
    resetClasses: function resetClasses() {
      var note = document.getElementsByClassName('note');
      var remove = document.getElementById("remove");
      for (var i = 0; i < note.length; i++) {
        note[i].className = "note";
      }
      remove.className = "remove";
    },
    addNote: function addNote() {
      var _this = this;

      if (this.newNote != null && this.newNote.trim().length > 0) {
        var imageUrl = undefined;

        var data = {
          text: this.newNote,
          date: new Date().toJSON().slice(0, 10).replace(/-/g, '/'),
          image: this.img
        };
        this.notes.push(data);
        this.img++;
        this.$nextTick(function () {
          _this.lastItem = document.getElementById("notes").lastChild;
          _this.lastItem.classList += " note--new";
          if (_this.template == "standard") _this.lastItem.style.backgroundColor = _this.getRandomColor();
          _this.newNote = null;
        });
      }
    },
    dragStart: function dragStart(event, index) {
      event.target.classList += " note--removing";
      this.selectedIndex = index;
      document.getElementById("remove").classList += " remove--active";
    },
    drop: function drop() {
      if (this.selectedIndex > -1) this.notes.splice(this.selectedIndex, 1);
      this.resetClasses();
    },
    dragEnter: function dragEnter() {
      document.getElementById("remove").classList += " remove--enter";
    },
    toggleLayout: function toggleLayout() {
      if (this.template == 'standard') {
        this.template = "modern";
        this.width = 500;
        this.height = 100;
      } else {
        this.template = 'standard';
        this.width = 100;
        this.height = 100;
        this.lastItem.style.backgroundColor = this.getRandomColor();
      }
    }
  },
  watch: {
    notes: function notes() {
      var _this2 = this;

      setTimeout(function () {
        _this2.lastItem.classList.remove("note--new");
      }, 50);
    }
  }
});