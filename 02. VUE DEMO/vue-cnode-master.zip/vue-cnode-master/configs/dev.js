module.exports = {
  dest: './dist/' // 程序打包后导出的目录
}
