module.exports = Object.assign({}, require('./base'), require('./dev'))
