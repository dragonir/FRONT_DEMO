module.exports = {
  target: 'https://cnodejs.org/', // api请求的目标网站
  base: '/vue-cnode/', // 路由根路径
  publicPath: '/vue-cnode/static/', // 程序文件在服务器所在的路径
  title: 'vue-cnode 中国最专业的 Node.js 开源技术社区'
}
