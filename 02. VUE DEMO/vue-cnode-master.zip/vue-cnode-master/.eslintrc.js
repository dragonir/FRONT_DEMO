module.exports = {
  root: true,
  extends: ['standard'],
  env: {
    browser: true,
  },
  plugins: [
    'html'
  ]
}