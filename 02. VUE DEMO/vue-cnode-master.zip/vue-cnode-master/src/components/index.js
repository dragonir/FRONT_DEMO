import header from './header'
import content from './content'
import footer from './footer'
import dataNull from './data-null'
import loading from './loading'
export default { header, content, footer, dataNull, loading }
