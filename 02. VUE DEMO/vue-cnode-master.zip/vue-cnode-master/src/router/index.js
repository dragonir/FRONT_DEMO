import router from './router'

export default router
