import vuet from './vuet'

export default vuet
