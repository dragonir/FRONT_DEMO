A Pen created at CodePen.io. You can find this one at https://codepen.io/ethiel97/pen/mWLRaN.

 Simple CRUD with vue.js for those willing to acquire the basics of this awesome javascript framework. Create , Read ,Update, Delete are made easy with this simple example