A Pen created at CodePen.io. You can find this one at https://codepen.io/ispal/pen/LxjgEj.

 Little reminder app prototype I created. All the animations/transitions you see on the app are made with CSS  which shows what you can do with it. This is also a Vue.js app.
--------------------------------------

--------------------------------------

### Update February 01, 2017

**Now you are able to set time by using voice commands (1-59 minutes) Click microphone and say eg. "timer 15 minutes"**

--------------------------------------

I highly recommend that you use **Chrome** to test this because it supports all the features I have used. Also this is not trying to be best practise of using Vue or the SCSS.

**Features**

- Speech recognition to reset timer & set time (up top 60 minutes)
- Speech syntheziser to give you warnings
- You are able to select the voice for warnings
- Select type of reminder

------------------------------------------------
Demo (without iframes):https://ispal.github.io/reminderapp/

Source: https://github.com/ispal/reminderapp

------------------------------
I got the original inspiration from Gal Shir's work on Dribbble
https://dribbble.com/shots/2396543-Water-Tracker

