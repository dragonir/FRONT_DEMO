A Pen created at CodePen.io. You can find this one at https://codepen.io/iamjoshellis/pen/yaAXmr.

 Just another todo app, tinkering with Vue.js this time. Writes to local storage for persistent data.