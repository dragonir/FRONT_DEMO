A Pen created at CodePen.io. You can find this one at https://codepen.io/chalharb/pen/LNRGNy.

 timesheet built using vue.js