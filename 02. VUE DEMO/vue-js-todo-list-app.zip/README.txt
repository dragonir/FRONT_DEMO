A Pen created at CodePen.io. You can find this one at http://codepen.io/ayoisaiah/pen/bZxbPV.

 A simple todo list application built with Vue.js