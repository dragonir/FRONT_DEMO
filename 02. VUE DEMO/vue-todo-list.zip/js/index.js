new Vue({
  el: '#app',
  
  data: {
    todos: [
      {
        id: 1,
        title: 'Learn Vue',
        completed: true
      }
    ],
    newTodo: {
      id: null,
      title: '',
      completed: false
    }
  },
  
  computed: {
    todoCount() {
      if(this.todos.length <= 5) {
        return this.todos.length;
      } else {
        return 'too many';
      }
      return this.todos.length;
    }
  },
  
  methods: {
    addNewTodo(newTodo) {
      this.todos.push(newTodo)
      this.newTodo = {id: null, title: '', completed: false}
    },
    
    todoCompleted(todo) {
      todo.completed = !todo.completed
    },
    
    deleteTodo(todo) {
      this.todos.$remove(todo)
    }
  }
})