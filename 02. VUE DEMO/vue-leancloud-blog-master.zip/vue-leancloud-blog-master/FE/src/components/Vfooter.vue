<template>
  <div>
    <p>Copyrights © 2016 将就. All Rights Reserved.</p>
  </div>
</template>

<style scoped>
  p {
    font-size: 1.4rem;
    margin: auto;
    color: #3d3d3d;
  }
</style>
