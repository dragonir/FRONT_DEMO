export const API_ROOT = (process.env.NODE_ENV === 'production')
  ? 'http://jiangjiu.leanapp.cn/'
  : 'http://localhost:3000/'
