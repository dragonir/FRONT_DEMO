// Developed by Glauber Funez
// Firebase vue.js + + vue fire
// Developed complex system (php, Webpack, js)
// Keep credits to Author