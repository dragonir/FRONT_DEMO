A Pen created at CodePen.io. You can find this one at https://codepen.io/knyttneve/pen/ZKgpgN.

 card design attempt with Vue.js