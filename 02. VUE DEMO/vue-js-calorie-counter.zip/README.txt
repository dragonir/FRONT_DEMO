A Pen created at CodePen.io. You can find this one at https://codepen.io/baublet/pen/WrqZwG.

 A simple Vue.js example for building version 2.0 of my website, w8mngr.com.