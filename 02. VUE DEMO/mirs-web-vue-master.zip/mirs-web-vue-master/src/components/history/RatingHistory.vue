<template>
  <div class="rating-history">
    评分记录
  </div>
</template>
