<template>
  <div class="settings">
    推荐设置
  </div>
</template>
