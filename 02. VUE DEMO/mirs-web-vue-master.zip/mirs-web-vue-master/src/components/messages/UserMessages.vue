<template>
  <div class="user-messages">
    用户私信
  </div>
</template>
