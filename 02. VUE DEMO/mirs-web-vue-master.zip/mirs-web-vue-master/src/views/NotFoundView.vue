<template>
  <div class="not-found-view">
    <h1>404</h1>
</template>

<style lang="stylus" scoped>
h1
  font-size 200px
  font-family 'Courgette', cursive
  color #8F8E8C
  text-align center
  margin-bottom 1px
  text-shadow 1px 1px 6px #fff
</style>
