/* the root getters */
