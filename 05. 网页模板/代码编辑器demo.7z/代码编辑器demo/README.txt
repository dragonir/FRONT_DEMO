A Pen created at CodePen.io. You can find this one at https://codepen.io/kazzkiq/pen/xGXaKR.

 No CodeMirror nor tons of files and weighty functions. This editor is made using only a little of CSS+JavaScript and the awesome Prism.js plugin for highlight!

Perfect fit for landing pages or when you want the user to edit or play with small pieces of code.