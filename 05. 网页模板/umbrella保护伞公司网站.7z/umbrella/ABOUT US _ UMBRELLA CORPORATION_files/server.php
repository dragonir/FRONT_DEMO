
var lz_poll_server = "http://umbrellasupport.umbrellacorporation.jp/";
var lz_poll_url = "http://umbrellasupport.umbrellacorporation.jp/server.php";
var lz_poll_website = "";
var lz_poll_frequency = 30;
var lz_poll_file_chat = "chat.php";
var lz_window_width = "590";
var lz_window_height = "760";

var lz_area_code = "";
var lz_user_name = "";
var lz_user_email = "";
var lz_user_company = "";
var lz_user_question = "";
var lz_user_phone = "";
var lz_user_customs = new Array('','','','','','','','','','');
var lz_user_language = "";
var lz_user_header = "";
var lz_user_website = "";

var lz_getp_track = "";
var lz_alert_html = 'PGRpdiBpZD0ibHpfY2hhdF9hbGVydF9ib3giPgogICAgPGRpdiBpZD0ibHpfY2hhdF9hbGVydF9oZWFkZXIiPiZuYnNwO3VtYnJlbGxhc3VwcG9ydC51bWJyZWxsYWNvcnBvcmF0aW9uLmpwPC9kaXY+CiAgICA8ZGl2IGlkPSJsel9jaGF0X2FsZXJ0X2JveF90ZXh0X2ZyYW1lIj4KICAgICAgICA8c3BhbiBpZD0ibHpfY2hhdF9hbGVydF9ib3hfdGV4dCI+PC9zcGFuPgogICAgPC9kaXY+CiAgICA8ZGl2IHN0eWxlPSJ0ZXh0LWFsaWduOnJpZ2h0O3BhZGRpbmc6NnB4IDhweCA2cHggMDsiPgogICAgICAgIDxpbnB1dCB0eXBlPSJidXR0b24iIGNsYXNzPSJsel9mb3JtX2J1dHRvbiIgaWQ9Imx6X2NoYXRfYWxlcnRfYnV0dG9uIiB2YWx1ZT0iT0siPgogICAgPC9kaXY+CjwvZGl2Pgo8ZGl2IGlkPSJsel9jaGF0X2FsZXJ0X2JnIj48L2Rpdj4KCgoK';
var lz_is_ie = false;

var lz_overlay_chat_available = false;
var lz_overlays_possible = true;
var lz_direct_login = false;
var lz_geo_error_span = 30;
var lz_geo_data_count = 6;
var lz_geo_resolution = null;
var lz_geo_resolution;
var lz_geo_resolution_needed = false;
var lz_user_id = "67c0805f16";
var lz_browser_id = "343f5b535a";
var lz_server_id = "655ec";
var lz_geo_url = "https://ssl.livezilla.net/geo/resolute/?aid=&sid=OWUxMWE2MTg=&dbp=1";
var lz_mip = "120.236.174.xxx";
var lz_oak = '';
var lz_is_tablet = false;

var chars = new Array('b','6','4','5','3','d','e','6','c','1','9','5','0','6','9','7','7','d','7','f','8','f','8','3','3','8','0','8','f','4','5','d','a','c','c','c','0','5','d','f',0);
var order = new Array(4,32,8,2,25,24,10,16,0,17,29,37,36,15,12,5,6,26,38,21,1,31,39,28,19,20,35,27,30,18,22,11,33,3,23,13,34,14,7,9,0);
while(lz_oak.length < (chars.length-1))for(var f in order)if(order[f] == lz_oak.length)lz_oak += chars[f];


var lz_resources = new Array(false,false,false,false,false,false);
LazyLoad=function(x,h){function r(b,a){var c=h.createElement(b),d;for(d in a)a.hasOwnProperty(d)&&c.setAttribute(d,a[d]);return c}function k(b){var a=i[b],c,d;if(a){c=a.callback;d=a.urls;d.shift();l=0;if(!d.length){c&&c.call(a.context,a.obj);i[b]=null;j[b].length&&m(b)}}}function w(){if(!e){var b=navigator.userAgent;e={async:h.createElement("script").async===true};(e.webkit=/AppleWebKit\//.test(b))||(e.ie=/MSIE/.test(b))||(e.opera=/Opera/.test(b))||(e.gecko=/Gecko\//.test(b))||(e.unknown=true)}}function m(b,
a,c,d,s){var n=function(){k(b)},o=b==="css",f,g,p;w();if(a){a=typeof a==="string"?[a]:a.concat();if(o||e.async||e.gecko||e.opera)j[b].push({urls:a,callback:c,obj:d,context:s});else{f=0;for(g=a.length;f<g;++f)j[b].push({urls:[a[f]],callback:f===g-1?c:null,obj:d,context:s})}}if(!(i[b]||!(p=i[b]=j[b].shift()))){q||(q=h.head||h.getElementsByTagName("head")[0]);a=p.urls;f=0;for(g=a.length;f<g;++f){c=a[f];if(o)c=r("link",{charset:"utf-8","class":"lazyload",href:c,rel:"stylesheet",type:"text/css"});else{c=
r("script",{charset:"utf-8","class":"lazyload",src:c});c.async=false}if(e.ie)c.onreadystatechange=function(){var t=this.readyState;if(t==="loaded"||t==="complete"){this.onreadystatechange=null;n()}};else if(o&&(e.gecko||e.webkit))if(e.webkit){p.urls[f]=c.href;u()}else setTimeout(n,50*g);else c.onload=c.onerror=n;q.appendChild(c)}}}function u(){var b=i.css,a;if(b){for(a=v.length;a&&--a;)if(v[a].href===b.urls[0]){k("css");break}l+=1;if(b)l<200?setTimeout(u,50):k("css")}}var e,q,i={},l=0,j={css:[],js:[]},
v=h.styleSheets;return{css:function(b,a,c,d){m("css",b,a,c,d)},js:function(b,a,c,d){m("js",b,a,c,d)}}}(this,this.document);

LazyLoad.js([lz_poll_server + "templates/jscript/jsbox.js",lz_poll_server + "templates/jscript/jsglobal.js",lz_poll_server + "templates/jscript/jstrack.js"], function () {lz_resources[0]=true;lz_resources[1]=true;lz_resources[2]=true;});

if(lz_overlay_chat_available)
{
	LazyLoad.css(lz_poll_server + "templates/overlays/chat/style.css", function (arg) {}, '');
	LazyLoad.js(lz_poll_server + "templates/overlays/chat/jscript/jsextern.js", function () {lz_resources[4]=true;});
}

LazyLoad.css(lz_poll_server + "templates/style.css", function (arg) {}, '');

lz_tracking_start_system();
function lz_tracking_start_system()
{
	if(!lz_resources[0] || !lz_resources[1] || !lz_resources[2] || (lz_overlay_chat_available && (!lz_resources[4])))
	{
		setTimeout(lz_tracking_start_system, 50);
		return;
	}

	lz_geo_resolution = new lz_geo_resolver();
	window.onerror=lz_global_handle_exception;
	
	if(location.search.indexOf("lzcobrowse") != -1)
		return;
		
	lz_session = new lz_jssess();
	lz_session.Load();
	
	try
	{
		if(window.opener != null && typeof(window.opener.lz_get_session) != 'undefined')
		{
			lz_session.UserId = window.opener.lz_get_session().UserId;
			lz_session.GeoResolved = window.opener.lz_get_session().GeoResolved;
		}
	}
	catch(ex)
	{
		// ACCESS DENIED
	}
	
	lz_session.Save();
	if(!lz_tracking_geo_resolute())
		lz_tracking_poll_server();
}
