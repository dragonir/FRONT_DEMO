A Pen created at CodePen.io. You can find this one at http://codepen.io/cobra_winfrey/pen/BzQrvM.

 (almost) pure CSS Neko Atsume cat (try to find the 2 characters without picking through the html- wanted to go full CSS but like this cat I am tired)