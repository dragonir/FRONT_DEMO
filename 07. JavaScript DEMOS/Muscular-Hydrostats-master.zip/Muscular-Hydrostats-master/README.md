###Muscular Hydrostats

An experiment with [inverse kinematics](http://en.wikipedia.org/wiki/Inverse_kinematics) to simulate tentacles.

[See it in action.](http://soulwire.github.com/Muscular-Hydrostats/)

Uses [sketch.js](https://github.com/soulwire/sketch.js) and [dat.GUI](http://code.google.com/p/dat-gui/)