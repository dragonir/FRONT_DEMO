<?php
sleep(10000);
?>
