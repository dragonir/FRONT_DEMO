A Pen created at CodePen.io. You can find this one at https://codepen.io/nxworld/pen/OyRrGy.

 Article - https://www.nxworld.net/tips/css-scroll-down-button.html